<?php

$cfg_server   = 'smtp.propertymatrimony.com';
$cfg_port     =  587;
$cfg_secure   = 'tls';
$cfg_username = 'leads@propertymatrimony.com';
$cfg_password = 'eCauj)@0';

