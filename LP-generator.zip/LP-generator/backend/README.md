# Landing Page Generator — Self-Hosted Backend

Turns a form submission into a ready-to-use landing page folder (index.html,
crm_connect.php, thanks.html, assets/) zipped up with a download link —
no n8n, no third-party workflow tool. Just PHP on your own hosting.

## Folder structure

```
backend/
├── generate.php                  ← the whole backend, one file
├── templates/                    ← protected, not web-accessible
│   ├── index-template.html       ← your site's HTML with {{TOKENS}}
│   ├── crm_connect-template.php  ← enquiry form handler with {{TOKENS}}
│   ├── config_smtp-template.php  ← your SMTP sender credentials (fixed)
│   ├── SMTPMailer.php            ← unchanged mailer class
│   └── thanks.html               ← unchanged thank-you page
├── assets/                       ← YOUR real css/js/fonts/default images go here
└── output/
    ├── submissions.csv           ← auto-created log of every request
    └── zips/                     ← generated .zip files land here (public)
```

## One-time setup (5 minutes)

1. **Upload the whole `backend/` folder** to your hosting via FTP/cPanel
   (anywhere PHP 7.4+ runs with the `ZipArchive` extension — nearly all
   shared hosting has this by default).

2. **Fill in `assets/`** with your real, unchanging files: `css/style.css`,
   `js/app.js`, fonts, and one default image per slot (`slider1.jpg`,
   `gallery1.jpg`, etc. — see `assets/PUT_YOUR_ASSETS_HERE.txt` for the
   full list). These act as fallback images if a visitor skips an upload.

3. **Set your SMTP sender details** in `templates/config_smtp-template.php`
   — this is the *sending* account (e.g. `leads@yourcompany.com`), same for
   every generated page. It's separate from the "Lead Email" field in the
   form, which is the *recipient* address and does change per project.

4. **Check folder permissions** — the web server needs write access to
   `output/` (typically `chmod 755 output` is enough; some hosts need `775`).

5. **Point the web app at your backend.** In `landing-page-request.html`,
   set:
   ```js
   const WEBHOOK_URL = "http://localhost/LP-generator/backend/generate.php";
   ```
   Host that HTML file anywhere (even a different domain — CORS is already
   allowed in `generate.php`).

That's it. No database, no cron job, no build step.

## How a request flows through `generate.php`

1. Validates the required fields (project name, address, phone, lead email,
   price range, and the first slider image) — rejects with a clear error
   if anything's missing.
2. Creates a temporary working folder named after the project + timestamp.
3. Copies your static `assets/` folder in first (so nothing's ever missing).
4. Saves each uploaded image over the matching default filename
   (`slider1.jpg`, `gallery2.jpg`, `logo.png`, etc.).
5. Builds the dynamic bits — highlight strip, pricing table rows, one
   floor-plan card per pricing row, gallery grid (only for photos actually
   uploaded), and the Google Maps embed — then fills every `{{TOKEN}}` in
   `index-template.html`.
6. Fills `crm_connect-template.php` with the lead's To/CC email and project
   name, so enquiries from *that* generated page go to the right inbox.
7. Zips the whole folder (`index.html`, `thanks.html`, `crm_connect.php`,
   `config_smtp.php`, `SMTPMailer.php`, `assets/…`) into
   `output/zips/<project-slug>-<timestamp>.zip`.
8. Deletes the temporary working folder (the zip already has everything).
9. Logs the submission to `output/submissions.csv` for your own records.
10. Responds with JSON: `{ "success": true, "downloadLink": "https://..." }`
    — this is what the web app reads to show the Download button instantly.

## Security notes worth knowing
- `templates/.htaccess` and `output/.htaccess` block direct web access to
  those folders (so nobody can browse to your SMTP password or the CSV log).
  `output/zips/.htaccess` re-opens *just* that subfolder so download links work.
- If your host uses Nginx instead of Apache, `.htaccess` files are ignored —
  add equivalent `deny all;` rules for `/templates/` and `/output/` (excluding
  `/output/zips/`) in your server block instead.
- Only `.jpg`, `.jpeg`, `.png`, and `.webp` uploads are accepted; anything
  else is silently skipped rather than saved.
- Consider adding a simple shared-secret header check in `generate.php` if
  the form will be public, so random visitors can't spam-generate zips.

## Troubleshooting
- **"Could not create working directory"** → `output/` isn't writable; check
  permissions.
- **Blank/500 response** → check your host's PHP error log; almost always
  a missing `ZipArchive` extension or a file-permission issue.
- **Download link 404s** → confirm `output/zips/.htaccess` uploaded correctly
  and that your host allows `.htaccess` overrides (`AllowOverride All`).
